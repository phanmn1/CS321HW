# 321Tests
I hadn't anticipated writing so many tests or really sharing them online.
I went back and added comments to some of the tests so if you're seeing a difference you have somewhere to start investigating.
